"use client";

interface PlatformItem {

  platform: string;

  amount: number;

  count: number;

  rate: number;

}


interface Props {

  data: PlatformItem[];

  // USD / CNY
  // 例如 7.20
  usdCny?: number;

}


export default function PlatformAllocation({

  data,

  usdCny = 0,

}: Props) {


  // =====================================================
  // 数据检查
  // =====================================================

  if (

    !Array.isArray(data) ||

    data.length === 0

  ) {

    return null;

  }


  // =====================================================
  // 汇率
  //
  // 人民币 → 美元
  //
  // CNY / USD
  //
  // 例如：
  // ¥720,000 / 7.2
  // = $100,000
  // =====================================================

  const exchangeRate =
    Number(usdCny) > 0
      ? Number(usdCny)
      : 0;


  // =====================================================
  // 香港判断
  //
  // platform 只要包含「香港」
  // 就归入香港
  //
  // 其他全部归大陆
  // =====================================================

  const isHongKongPlatform = (
    platform: string
  ) => {

    return String(
      platform || ""
    ).includes("香港");

  };


  // =====================================================
  // 原始人民币总资产
  //
  // 所有占比都使用人民币原始金额计算
  // =====================================================

  const total =
    data.reduce(

      (
        sum,
        item
      ) => {

        return (
          sum +
          Number(
            item.amount || 0
          )
        );

      },

      0

    );


  // =====================================================
  // 香港平台
  // =====================================================

  const hongKongPlatforms =
    data.filter(
      (
        item
      ) =>
        isHongKongPlatform(
          item.platform
        )
    );


  // =====================================================
  // 大陆平台
  //
  // 不包含「香港」
  // 全部归大陆
  // =====================================================

  const mainlandPlatforms =
    data.filter(
      (
        item
      ) =>
        !isHongKongPlatform(
          item.platform
        )
    );


  // =====================================================
  // 香港人民币总额
  // =====================================================

  const hongKongCnyTotal =
    hongKongPlatforms.reduce(

      (
        sum,
        item
      ) => {

        return (
          sum +
          Number(
            item.amount || 0
          )
        );

      },

      0

    );


  // =====================================================
  // 大陆人民币总额
  // =====================================================

  const mainlandCnyTotal =
    mainlandPlatforms.reduce(

      (
        sum,
        item
      ) => {

        return (
          sum +
          Number(
            item.amount || 0
          )
        );

      },

      0

    );


  // =====================================================
  // 香港美元总额
  // =====================================================

  const hongKongUsdTotal =
    exchangeRate > 0

      ? hongKongCnyTotal /
        exchangeRate

      : hongKongCnyTotal;


  // =====================================================
  // 格式化人民币
  // =====================================================

  const formatCny = (
    value: number
  ) => {

    return `¥${Math.round(
      value
    ).toLocaleString(
      "zh-CN"
    )}`;

  };


  // =====================================================
  // 格式化美元
  // =====================================================

  const formatUsd = (
    value: number
  ) => {

    return `$${Math.round(
      value
    ).toLocaleString(
      "en-US"
    )}`;

  };


  // =====================================================
  // 格式化百分比
  //
  // rate 本身是：
  // 0.25
  //
  // 显示：
  // 25.0%
  // =====================================================

  const formatPercent = (
    value: number
  ) => {

    return `${(
      value * 100
    ).toFixed(1)}%`;

  };


  // =====================================================
  // 平台金额
  //
  // 香港：
  // CNY → USD
  //
  // 大陆：
  // CNY
  // =====================================================

  const formatPlatformAmount = (
    item: PlatformItem
  ) => {

    const amount =
      Number(
        item.amount || 0
      );


    if (
      isHongKongPlatform(
        item.platform
      )
    ) {

      if (
        exchangeRate > 0
      ) {

        return formatUsd(
          amount /
          exchangeRate
        );

      }


      return formatCny(
        amount
      );

    }


    return formatCny(
      amount
    );

  };


  // =====================================================
  // 分组标题
  // =====================================================

  const renderGroup = (

    title: string,

    icon: string,

    platforms: PlatformItem[],

    groupCnyTotal: number,

    isHongKong: boolean

  ) => {

    if (
      platforms.length === 0
    ) {

      return null;

    }


    const groupRate =
      total > 0

        ? groupCnyTotal /
          total

        : 0;


    const groupDisplayAmount =
      isHongKong

        ? (
            exchangeRate > 0

              ? groupCnyTotal /
                exchangeRate

              : groupCnyTotal
          )

        : groupCnyTotal;


    return (

      <div
        className="
          rounded-2xl
          border
          border-gray-100
          overflow-hidden
        "
      >

        {/* =============================================
            Group Header
        ============================================= */}

        <div
          className="
            bg-gray-50
            px-6
            py-5
          "
        >

          <div
            className="
              flex
              items-center
              justify-between
              gap-4
            "
          >

            <div>

              <div
                className="
                  flex
                  items-center
                  gap-2
                "
              >

                <span
                  className="
                    text-xl
                  "
                >
                  {icon}
                </span>


                <h3
                  className="
                    text-lg
                    font-bold
                    text-gray-900
                  "
                >
                  {title}
                </h3>

              </div>


              <p
                className="
                  mt-1
                  text-sm
                  text-gray-400
                "
              >
                {platforms.length} 个平台
              </p>

            </div>


            <div
              className="
                text-right
              "
            >

              <p
                className="
                  text-xl
                  font-bold
                  text-gray-900
                "
              >
                {
                  isHongKong
                    ? formatUsd(
                        groupDisplayAmount
                      )
                    : formatCny(
                        groupDisplayAmount
                      )
                }
              </p>


              <p
                className="
                  mt-1
                  text-sm
                  text-gray-400
                "
              >
                {formatPercent(
                  groupRate
                )}
              </p>

            </div>

          </div>

        </div>


        {/* =============================================
            Platform List
        ============================================= */}

        <div
          className="
            p-6
            space-y-5
          "
        >

          {
            platforms.map(
              (
                item,
                index
              ) => {

                const rate =
                  Number(
                    item.rate || 0
                  );


                return (

                  <div
                    key={
                      `${item.platform}-${index}`
                    }
                  >

                    {/* =================================
                        Name / Amount
                    ================================= */}

                    <div
                      className="
                        flex
                        items-center
                        justify-between
                        gap-4
                      "
                    >

                      <div
                        className="
                          min-w-0
                          flex-1
                        "
                      >

                        <div
                          className="
                            flex
                            items-center
                            gap-2
                          "
                        >

                          <span
                            className="
                              font-semibold
                              text-gray-900
                              truncate
                            "
                          >
                            {item.platform}
                          </span>


                          <span
                            className="
                              text-xs
                              text-gray-400
                              whitespace-nowrap
                            "
                          >
                            {item.count} 项
                          </span>

                        </div>

                      </div>


                      <div
                        className="
                          text-right
                          whitespace-nowrap
                        "
                      >

                        <span
                          className="
                            font-semibold
                            text-gray-900
                          "
                        >
                          {formatPlatformAmount(
                            item
                          )}
                        </span>


                        <span
                          className="
                            ml-3
                            text-sm
                            text-gray-400
                          "
                        >
                          {formatPercent(
                            rate
                          )}
                        </span>

                      </div>

                    </div>


                    {/* =================================
                        Progress
                    ================================= */}

                    <div
                      className="
                        mt-2
                        h-2
                        bg-gray-100
                        rounded-full
                        overflow-hidden
                      "
                    >

                      <div
                        className="
                          h-full
                          bg-gray-900
                          rounded-full
                          transition-all
                          duration-500
                        "
                        style={{
                          width:
                            `${Math.min(
                              rate * 100,
                              100
                            )}%`,
                        }}
                      />

                    </div>

                  </div>

                );

              }
            )
          }

        </div>


        {/* =============================================
            Group Footer
        ============================================= */}

        <div
          className="
            border-t
            border-gray-100
            px-6
            py-4
            flex
            items-center
            justify-between
            text-sm
          "
        >

          <span
            className="
              text-gray-400
            "
          >
            {title}合计
          </span>


          <div
            className="
              text-right
            "
          >

            <span
              className="
                font-bold
                text-gray-900
              "
            >
              {
                isHongKong
                  ? formatUsd(
                      groupDisplayAmount
                    )
                  : formatCny(
                      groupDisplayAmount
                    )
              }
            </span>


            <span
              className="
                ml-3
                text-gray-400
              "
            >
              {formatPercent(
                groupRate
              )}
            </span>

          </div>

        </div>

      </div>

    );

  };


  // =====================================================
  // 页面
  // =====================================================

  return (

    <div
      className="
        bg-white
        rounded-2xl
        shadow-sm
        border
        border-gray-100
        p-8
      "
    >

      {/* =================================================
          Header
      ================================================= */}

      <div
        className="
          flex
          items-center
          justify-between
          mb-7
        "
      >

        <div>

          <h2
            className="
              text-2xl
              font-bold
              text-gray-900
            "
          >
            🏦 Platform Allocation
          </h2>


          <p
            className="
              mt-1
              text-sm
              text-gray-400
            "
          >
            按资产存放地区及平台统计当前持仓
          </p>

        </div>


        <div
          className="
            text-right
          "
        >

          <p
            className="
              text-sm
              text-gray-400
            "
          >
            平台数量
          </p>


          <p
            className="
              mt-1
              text-2xl
              font-bold
              text-gray-900
            "
          >
            {data.length}
          </p>

        </div>

      </div>


      {/* =================================================
          总览
      ================================================= */}

      <div
        className="
          grid
          grid-cols-1
          md:grid-cols-3
          gap-4
          mb-7
        "
      >

        {/* ===============================================
            Total
        =============================================== */}

        <div
          className="
            rounded-xl
            bg-gray-50
            p-5
          "
        >

          <p
            className="
              text-sm
              text-gray-400
            "
          >
            Holdings 总市值
          </p>


          <p
            className="
              mt-2
              text-2xl
              font-bold
              text-gray-900
            "
          >
            {formatCny(
              total
            )}
          </p>

        </div>


        {/* ===============================================
            Hong Kong
        =============================================== */}

        <div
          className="
            rounded-xl
            bg-blue-50
            p-5
          "
        >

          <p
            className="
              text-sm
              text-gray-500
            "
          >
            🇭🇰 香港
          </p>


          <p
            className="
              mt-2
              text-2xl
              font-bold
              text-blue-700
            "
          >
            {
              formatUsd(
                hongKongUsdTotal
              )
            }
          </p>


          <p
            className="
              mt-1
              text-sm
              text-blue-500
            "
          >
            {formatPercent(
              total > 0
                ? hongKongCnyTotal /
                  total
                : 0
            )}
          </p>

        </div>


        {/* ===============================================
            Mainland
        =============================================== */}

        <div
          className="
            rounded-xl
            bg-green-50
            p-5
          "
        >

          <p
            className="
              text-sm
              text-gray-500
            "
          >
            🇨🇳 大陆
          </p>


          <p
            className="
              mt-2
              text-2xl
              font-bold
              text-green-700
            "
          >
            {formatCny(
              mainlandCnyTotal
            )}
          </p>


          <p
            className="
              mt-1
              text-sm
              text-green-600
            "
          >
            {formatPercent(
              total > 0
                ? mainlandCnyTotal /
                  total
                : 0
            )}
          </p>

        </div>

      </div>


      {/* =================================================
          香港
      ================================================= */}

      {
        renderGroup(
          "香港",
          "🇭🇰",
          hongKongPlatforms,
          hongKongCnyTotal,
          true
        )
      }


      {/* =================================================
          大陆
      ================================================= */}

      {
        mainlandPlatforms.length > 0 && (

          <div
            className="
              mt-6
            "
          >

            {
              renderGroup(
                "大陆",
                "🇨🇳",
                mainlandPlatforms,
                mainlandCnyTotal,
                false
              )
            }

          </div>

        )
      }


      {/* =================================================
          汇率说明
      ================================================= */}

      {
        hongKongPlatforms.length > 0 && (

          <div
            className="
              mt-6
              rounded-xl
              bg-gray-50
              px-5
              py-4
              text-sm
              text-gray-500
            "
          >

            <div
              className="
                flex
                items-center
                justify-between
                gap-4
              "
            >

              <span>
                香港资产显示货币
              </span>


              <span
                className="
                  font-semibold
                  text-gray-700
                "
              >
                {
                  exchangeRate > 0
                    ? `USD/CNY ${exchangeRate.toFixed(
                        4
                      )}`
                    : "汇率未设置"
                }
              </span>

            </div>


            <p
              className="
                mt-1
                text-xs
                text-gray-400
              "
            >
              香港平台人民币市值 ÷ USD/CNY = 美元市值
            </p>

          </div>

        )

      }


      {/* =================================================
          Footer
      ================================================= */}

      <div
        className="
          mt-7
          pt-5
          border-t
          border-gray-100
          flex
          items-center
          justify-between
          text-sm
        "
      >

        <span
          className="
            text-gray-400
          "
        >
          Platform Total
        </span>


        <div
          className="
            text-right
          "
        >

          <span
            className="
              font-bold
              text-gray-900
            "
          >
            {formatCny(
              total
            )}
          </span>


          <span
            className="
              ml-3
              text-gray-400
            "
          >
            100.0%
          </span>

        </div>

      </div>

    </div>

  );

}